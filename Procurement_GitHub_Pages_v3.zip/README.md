# Procurement Intelligence — Local Data Edition
Static dashboard. No backend, API requests, external libraries, CDN, or embedded business data. Select a locally exported `dashboard_snapshot.json` to start. The page holds the selected snapshot in memory until disconnected or closed; it does not persist it to browser storage. The displayed generation is the exported snapshot, not current database status.

## Publish
Upload the contents of this folder (index.html, style.css, local-data.js, app.js, .nojekyll) to a dedicated GitHub repository only if the code is approved for publication. Settings > Pages > Deploy from a branch > main > /(root). GitHub Pages may be public even for a private repository. Free personal GitHub Pages generally requires a public repository. Never upload the snapshot, source Excel, database, backups, credentials or logs. The public-facing brand is generic.

## Use
Chrome or Edge recommended. Select Data Folder opens the folder picker where supported; Select JSON file is the fallback. Reload Data rereads the file with a valid folder handle or opens a file picker. If the page is reloaded, select the folder again. Snapshot maximum 200 MiB; use the local backend version for larger files. Local browser calculations use JavaScript floating-point numbers; the exported source decimals remain strings. For audited exact totals use PostgreSQL. Reports download as CSV (Excel-compatible, not XLSX); import identifiers as text in Excel to preserve leading zeros.

## Security
Only select the dedicated export folder, never the raw Excel folder or credentials folder. CSP blocks network fetches; scripts are local to the deployed site. Hosted code can change on future deployments, so control repository write access, review code and use the approved version. Keep actual business data local and use only if employer policy permits. GitHub Pages is not an authentication layer. Other devices need their own copy of the snapshot; they cannot access your laptop folder remotely. Disconnect clears the active in-memory snapshot but cannot revoke previously downloaded CSVs.
